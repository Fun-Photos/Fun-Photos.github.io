import { default as default2 } from "../components/pages/_page.svelte-63ca46e9.js";
export {
  default2 as component
};
