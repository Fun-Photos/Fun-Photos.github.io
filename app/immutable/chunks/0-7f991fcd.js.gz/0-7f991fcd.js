import { default as default2 } from "../components/pages/_layout.svelte-2b0efb65.js";
export {
  default2 as component
};
