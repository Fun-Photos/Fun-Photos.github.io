import { default as default2 } from "../components/error.svelte-e6cfd883.js";
export {
  default2 as component
};
