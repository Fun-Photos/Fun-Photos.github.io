import { default as default2 } from "../components/error.svelte-1c1eec2c.js";
export {
  default2 as component
};
