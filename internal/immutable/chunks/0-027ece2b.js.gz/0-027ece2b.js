import { default as default2 } from "../components/pages/_layout.svelte-33f20fca.js";
export {
  default2 as component
};
