import { default as default2 } from "../components/error.svelte-20f2db69.js";
export {
  default2 as component
};
