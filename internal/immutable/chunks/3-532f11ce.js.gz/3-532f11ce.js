import { default as default2 } from "../components/pages/about/_page.svelte-0a4fbb08.js";
export {
  default2 as component
};
