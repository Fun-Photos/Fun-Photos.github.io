import { default as default2 } from "../components/pages/_page.svelte-58c02a34.js";
export {
  default2 as component
};
